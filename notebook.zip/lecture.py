# /// script
# requires-python = ">=3.12"
# dependencies = ["marimo==0.23.9", "numpy>=2.0", "matplotlib>=3.9"]
# ///

import marimo

__generated_with = "0.23.9"
app = marimo.App(width="full", app_title="Statistical learning · MATH6331", css_file="theme.css", layout_file="layouts/lecture.slides.json")

@app.cell
def _():
    import marimo as mo
    import numpy as np
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from io import StringIO
    return mo, np, plt, StringIO


@app.cell
def _(StringIO, mo, np, plt):
    C = dict(ink="#1a1a34", muted="#6b6b80", training="#6472e2", test="#89e990", test_edge="#1a3d36", validation="#89e990", validation_edge="#1a3d36", fit="#1a1a34", truth="#1a3d36", accent="#89e990", purple="#c5a9ff", pale="#f4f4f8", bg="#ffffff")
    plt.rcParams.update({"font.family":"DejaVu Sans", "font.size":11, "axes.spines.top":False, "axes.spines.right":False, "axes.edgecolor":"#d5d5df", "axes.labelcolor":C["muted"], "xtick.color":C["muted"], "ytick.color":C["muted"], "text.color":C["ink"], "axes.titleweight":"normal", "axes.titlesize":12, "figure.facecolor":C["bg"], "axes.facecolor":C["bg"], "svg.fonttype":"none"})

    def truth(x):
        return 0.5 + 1.15*x + 0.85*np.cos(3.7*x)

    def sample_data(n, noise, seed=6):
        # Separate streams: changing n preserves the existing observations.
        x = np.random.default_rng(seed).uniform(-1, 1, 240)[:n]
        eps = np.random.default_rng(seed+1000).normal(size=240)[:n]
        return x, truth(x)+noise*eps

    def fit_poly(x, y, degree):
        return np.polynomial.Legendre.fit(x, y, degree, domain=[-1,1])

    def fig_html(fig):
        buf=StringIO()
        fig.savefig(buf, format="svg", bbox_inches="tight", pad_inches=0.15)
        plt.close(fig)
        return mo.Html('<div class="plot">'+buf.getvalue()+'</div>')

    def axes_pair():
        fig, axes=plt.subplots(1,2,figsize=(12.4,3.5), gridspec_kw={"wspace":0.27})
        for ax in axes:
            ax.grid(axis="y", color="#ececf1", linewidth=.65, zorder=0)
            ax.set_axisbelow(True)
        return fig, axes

    def tag(text):
        return mo.Html('<div class="eyebrow">'+text+'</div>')

    def prompt(text):
        return mo.Html('<div class="prompt">'+mo.md(text).text+'</div>')

    def cards(items):
        return mo.Html('<div class="cards">'+''.join('<div class="card"><div class="card-value">'+b+'</div><p>'+mo.md(c).text+'</p></div>' for _,b,c in items)+'</div>')

    def panels(items):
        return mo.Html('<div class="math-panels">'+''.join('<div class="math-panel"><h2>'+title+'</h2>'+mo.md(body).text+'</div>' for title,body in items)+'</div>')

    def slide(kicker, title, body, foot="", number=""):
        header = '<div class="brand-bar"><span class="mars-logo" role="img" aria-label="MARS"></span><span class="brand-cross">×</span><span class="lu-logo" role="img" aria-label="Lancaster University"></span></div>'
        footer = '<div class="footer"><span>MATH6331</span><span>'+foot+'</span><span>'+number+'</span></div>'
        content = mo.vstack([tag(kicker), mo.Html('<h1 class="lecture-title">'+title+'</h1>'), *body, mo.Html(footer)], gap=.6)
        return mo.Html('<div class="lecture">'+header+'<div class="slide-body">'+content.text+'</div></div>')

    return C, truth, sample_data, fit_poly, fig_html, axes_pair, tag, prompt, cards, panels, slide


@app.cell
def _(C, fig_html, fit_poly, mo, np, plt, sample_data, slide, truth):
    _g = np.linspace(-1,1,350)
    _f, _a = plt.subplots(figsize=(11.8,2.25))
    _x, _y=sample_data(35,.38)
    _a.scatter(_x,_y,s=24,color=C["training"],alpha=.65,edgecolors="none")
    _a.plot(_g,truth(_g),color=C["truth"],lw=2,ls="--")
    _a.plot(_g,fit_poly(_x,_y,7)(_g),color=C["fit"],lw=2)
    _a.axis("off")
    slide("MATH6331 · CHAPTER 6", "Statistical learning", [mo.Html('<p class="lede">Prediction, model flexibility and validation.</p>'),fig_html(_f),mo.Html('<p class="small">6 November 2026</p>')], "", "01")


@app.cell
def _(mo):
    example_training=mo.ui.switch(value=False,label="Training points")
    example_observed=mo.ui.switch(value=True,label="New observation")
    return example_training, example_observed


@app.cell
def _(C, example_observed, example_training, fig_html, fit_poly, mo, np, plt, sample_data, slide):
    _xtrain,_ytrain=sample_data(30,.45)
    _fit=fit_poly(_xtrain,_ytrain,6)
    _xnew=.4
    _prediction=float(_fit(_xnew))
    _observed=_prediction+.6
    _grid=np.linspace(-1,1,350)
    _fig,_ax=plt.subplots(figsize=(5.7,3.1))
    if example_training.value:
        _ax.scatter(_xtrain,_ytrain,s=25,color=C["training"],alpha=.6,label="Training observations")
    _ax.plot(_grid,_fit(_grid),color=C["fit"],lw=2,label="Fitted curve f")
    if example_observed.value:
        _ax.plot([_xnew,_xnew],[_prediction,_observed],color=C["test_edge"],lw=2.5)
    _ax.scatter([_xnew],[_prediction],s=50,facecolors="white",edgecolors=C["fit"],zorder=4)
    if example_observed.value:
        _ax.scatter([_xnew],[_observed],s=80,color=C["test"],edgecolors=C["test_edge"],alpha=1,marker="X",linewidths=.7,zorder=4)
    if example_observed.value:
        _ax.annotate(r"observed $y$",(_xnew,_observed),xytext=(12,5),textcoords="offset points",color=C["test_edge"])
    _ax.annotate(r"prediction $f(x)$",(_xnew,_prediction),xytext=(12,-16),textcoords="offset points",color=C["fit"])
    _ax.set(xlim=(-1,1),ylim=(-2.4,2.5),xlabel="Input x",ylabel="Response y")
    _ax.legend(loc="upper left",fontsize=9,frameon=False)
    _example=mo.md(rf"""
    **One new observation**

    We observe $x$ and predict $f(x)$.
    When $y$ becomes available, the squared error is

    $$\begin{{aligned}}(y-f(x))^2
    &=({_observed:.2f}-{_prediction:.2f})^2\\
    &=0.36.\end{{aligned}}$$

    Repeat for other new observations and average their squared errors.
    """)
    _body=mo.Html('<div class="prediction-example"><div class="example-figure">'+fig_html(_fig).text+'</div><div class="example-text">'+_example.text+'</div></div>')
    slide("6.2", "Error on a new observation", [mo.md("We have fitted a curve to earlier data. How well does it predict a new response?"),mo.hstack([example_training,example_observed],justify="start",gap=2),_body,mo.md(r"""
    **Test loss** is the average squared error on a test sample. It estimates
    **predictive risk** $R(f)$, the average squared error over the population.
    """)],"", "02")


@app.cell
def _(mo):
    risk_resample=mo.ui.button(value=0,on_click=lambda v:v+1,label="New test sample")
    risk_size=mo.ui.slider(steps=[10,25,50,100,500],value=25,label="Test sample size m",show_value=True)
    risk_reveal=mo.ui.switch(value=False,label="Show population mean")
    risk_training=mo.ui.switch(value=True,label="Training points")
    risk_test=mo.ui.switch(value=True,label="Test points")
    return risk_resample, risk_size, risk_reveal, risk_training, risk_test


@app.cell
def _(C, axes_pair, fig_html, fit_poly, mo, np, panels, risk_resample, risk_reveal, risk_size, risk_test, risk_training, sample_data, slide, truth):
    _rx,_ry=sample_data(30,.45)
    _rf=fit_poly(_rx,_ry,6)
    _rg=np.linspace(-1,1,1500)
    _rr=np.random.default_rng(400+int(risk_resample.value))
    _rtx=_rr.uniform(-1,1,500)[:risk_size.value]
    _rty=truth(_rtx)+.45*_rr.normal(size=500)[:risk_size.value]
    _rmsetrain=float(np.mean((_ry-_rf(_rx))**2))
    _rmsetest=float(np.mean((_rty-_rf(_rtx))**2))
    _rrisk=float(np.mean((_rf(_rg)-truth(_rg))**2)+.45**2)
    _rfig,_rax=axes_pair()
    if risk_training.value:
        _rax[0].scatter(_rx,_ry,s=25,color=C["training"],alpha=.6,label="Training observations")
    if risk_test.value:
        _rax[0].scatter(_rtx,_rty,s=45,color=C["test"],edgecolors=C["test_edge"],alpha=1,marker="X",linewidths=.7,label="Fresh test observations")
    _rax[0].plot(_rg,_rf(_rg),color=C["ink"],lw=2,label="Fixed fitted curve")
    if risk_reveal.value: _rax[0].plot(_rg,truth(_rg),color=C["truth"],lw=2,ls="--",label="Population mean")
    _rax[0].set(xlabel="Covariate x",ylabel="Response y",ylim=(-2.5,3.5),title="A fixed fitted function")
    _rax[0].legend(fontsize=8,loc="lower right")
    _rax[1].bar([0,1,2],[_rmsetrain,_rmsetest,_rrisk],color=[C["training"],C["test"],C["truth"]],edgecolor=[C["training"],C["test_edge"],C["truth"]],linewidth=.7,width=.55)
    _rax[1].set(xticks=[0,1,2],xticklabels=["Training loss\nfixed","Test loss\nsample estimate","Predictive risk\nfixed"],ylabel="Average squared error",ylim=(0,max(.8,_rmsetest*1.2,_rrisk*1.2)),title="Test loss estimates predictive risk")
    _definitions=panels([
        ("Test loss: sample average",r"""
        $$\widehat R_m(f)=\frac1m\sum_{j=1}^m(Y_j-f(X_j))^2.$$
        """),
        ("Predictive risk: population average",r"""
        $$R(f)=\int (y-f(x))^2\,dP(x,y).$$
        """)])
    slide("6.2", "Test loss estimates predictive risk", [
        mo.md(r"""
        Fix the fitted function $f$ and population law $P$, with $R(f)<\infty$.
        The test observations $(X_j,Y_j)$ are i.i.d. from $P$, independent of the training data.
        """),
        mo.hstack([risk_size,risk_resample,risk_reveal,risk_training,risk_test],justify="start",gap=2),
        fig_html(_rfig),
        mo.Html('<p class="small">Risk bar: numerical integration using the known population law.</p>'),
        mo.Html('<div class="risk-definitions">'+_definitions.text+'</div>'),
        mo.md(r"""
        For this fixed $f$, $\mathbb E[\widehat R_m(f)]=R(f)$.
        Resampling changes the test loss; changing $m$ changes its sampling variability.
        Neither changes $R(f)$.
        """)],"", "03")


@app.cell
def _(mo):
    procedure_size=mo.ui.slider(steps=[100,1000,10000,50000],value=10000,label="Test sample size m",show_value=True)
    procedure_resample=mo.ui.button(value=0,on_click=lambda v:v+1,label="New test sample")
    procedure_training=mo.ui.switch(value=True,label="Training points")
    procedure_test=mo.ui.switch(value=True,label="Test points")
    return procedure_size, procedure_resample, procedure_training, procedure_test


@app.cell
def _(fit_poly, np, procedure_resample, procedure_size, sample_data, truth):
    procedure_samples=[sample_data(30,.45,seed) for seed in [6,7,8]]
    procedure_fits=[fit_poly(x,y,6) for x,y in procedure_samples]
    # The same independent test sample assesses all three fits. Prefixes are nested in m.
    _rng=np.random.default_rng(8100+int(procedure_resample.value))
    procedure_test_x=_rng.uniform(-1,1,50000)[:procedure_size.value]
    procedure_test_y=truth(procedure_test_x)+.45*_rng.normal(size=50000)[:procedure_size.value]
    procedure_losses=np.array([np.mean((procedure_test_y-f(procedure_test_x))**2) for f in procedure_fits])
    return procedure_samples, procedure_fits, procedure_test_x, procedure_test_y, procedure_losses


@app.cell
def _(C, fig_html, mo, np, plt, procedure_fits, procedure_losses, procedure_resample, procedure_samples, procedure_size, procedure_test, procedure_test_x, procedure_test_y, procedure_training, slide):
    _fig,_axes=plt.subplots(1,3,figsize=(12.4,3.0),sharex=True,sharey=True)
    _grid=np.linspace(-1,1,350)
    for _j,(_ax,(_x,_y),_f,_loss) in enumerate(zip(_axes,procedure_samples,procedure_fits,procedure_losses),1):
        if procedure_test.value:
            _ax.scatter(procedure_test_x[:200],procedure_test_y[:200],s=22,color=C["test"],edgecolors=C["test_edge"],alpha=1,marker="X",linewidths=.7,label="Test observations")
        if procedure_training.value:
            _ax.scatter(_x,_y,s=25,color=C["training"],alpha=.6,label="Training observations")
        _ax.plot(_grid,_f(_grid),lw=2,color=C["fit"])
        _ax.set(xlim=(-1,1),ylim=(-2.5,3.5),title=f"Training sample {_j}",xlabel=rf"Test loss $\widehat R_m(f_{_j})={_loss:.3f}$")
        _ax.grid(axis="y",color="#ececf1",lw=.6)
        _ax.set_axisbelow(True)
    _axes[0].set_ylabel("Response y")
    if procedure_training.value or procedure_test.value:
        _axes[0].legend(fontsize=7,loc="lower right")
    _average=float(procedure_losses.mean())
    slide("6.2", "Error of a fitting procedure", [
        mo.md("Fit the same rule to three training samples: 30 observations, degree 6, least squares."),
        mo.hstack([procedure_size,procedure_resample,procedure_training,procedure_test],justify="start",gap=2),
        mo.Html('<div class="procedure-figure">'+fig_html(_fig).text+'</div>'),
        mo.Html(f'<p class="small">At most 200 test points shown; all {procedure_size.value:,} used in each test loss.</p>'),
        mo.md(rf"""
        Assess each curve on the same **{procedure_size.value:,} independent test observations**:

        $$R(f_i)\approx\widehat R_m(f_i)=\frac1m\sum_{{j=1}}^m(Y_j-f_i(X_j))^2.$$

        Their mean test loss is **{_average:.3f}**. It estimates the risk of the **fitting procedure**.
        """),
        mo.accordion({"Two averages":mo.md(r"""
        Let $A$ be the fitting rule and $D$ a random training sample of size $n$.
        First average over test observations to estimate each $R(f_i)$.
        Then average over training samples to estimate

        $$R_n(A)=\mathbb E_D[R(A(D))]\approx\frac13\sum_{i=1}^3\widehat R_m(f_i).$$

        A large test sample improves the first approximation. Three training samples give only a rough estimate of the second.
        """)})],"", "04")


@app.cell
def _(mo, slide):
    slide("6.2", "Why training loss is optimistic", [mo.md(r"""
    For a training sample $D=((X_i,Y_i))_{i=1}^n$ of i.i.d. observations from $P$, define

    $$\widehat R_D(f)=\frac1n\sum_{i=1}^n(Y_i-f(X_i))^2.$$

    Least squares chooses $f_D$ to minimise this loss over a fixed class $\mathcal F$:

    $$f_D\in\operatorname*{arg\,min}_{f\in\mathcal F}\widehat R_D(f).$$

    Assume a minimiser exists and all expectations are finite. Averaging over training samples gives

    $$\mathbb E_D[\widehat R_D(f_D)]\leq\mathbb E_D[R(f_D)].$$

    The right-hand side is the risk of the fitting procedure.
    The inequality need not hold for each individual sample.
    """),mo.accordion({"Proof":mo.md(r"""
    Fix any $f\in\mathcal F$, independently of the training sample $D$.
    Since $f_D$ minimises training loss,

    $$\widehat R_D(f_D)\leq\widehat R_D(f).$$

    Take expectations over $D$. Each squared error for the fixed $f$ has expectation $R(f)$, so

    $$\mathbb E_D[\widehat R_D(f_D)]
    \leq\mathbb E_D[\widehat R_D(f)]=R(f).$$

    The left side does not depend on our choice of $f$.
    It is therefore a lower bound for every value $R(f)$, and hence for their infimum:

    $$\mathbb E_D[\widehat R_D(f_D)]\leq\inf_{f\in\mathcal F}R(f).$$

    For every training sample, $f_D\in\mathcal F$, so $R(f_D)\geq\inf_{f\in\mathcal F}R(f)$.
    Averaging this inequality completes the proof:

    $$\mathbb E_D[\widehat R_D(f_D)]
    \leq\inf_{f\in\mathcal F}R(f)
    \leq\mathbb E_D[R(f_D)].$$
    """)})],"", "05")


@app.cell
def _(mo):
    degree=mo.ui.slider(1,12,value=3,label="Polynomial degree",show_value=True,debounce=True)
    points=mo.ui.slider(steps=[20,30,50,80,120,200],value=50,label="Training observations",show_value=True,debounce=True)
    noise=mo.ui.slider(0,.9,step=.05,value=.35,label="Noise σ",show_value=True,debounce=True)
    new_sample=mo.ui.button(value=0,on_click=lambda v:v+1,label="New training sample")
    show_truth=mo.ui.switch(value=True,label="Population mean")
    polynomial_training=mo.ui.switch(value=True,label="Training points")
    polynomial_validation=mo.ui.switch(value=False,label="Validation points")
    return degree, points, noise, new_sample, show_truth, polynomial_training, polynomial_validation


@app.cell
def _(fit_poly, new_sample, noise, np, points, sample_data, truth):
    fx,fy=sample_data(points.value,noise.value,6+int(new_sample.value))
    grid=np.linspace(-1,1,1200)
    models=[fit_poly(fx,fy,d) for d in range(1,13)]
    train_errors=np.array([np.mean((m(fx)-fy)**2) for m in models])
    # This set is used across degrees: it is validation data, not a final test set.
    _vrng=np.random.default_rng(91)
    validation_x=_vrng.uniform(-1,1,1200)
    validation_y=truth(validation_x)+noise.value*_vrng.normal(size=1200)
    validation_errors=np.array([np.mean((m(validation_x)-validation_y)**2) for m in models])
    population_errors=np.array([np.mean((m(grid)-truth(grid))**2)+noise.value**2 for m in models])
    return fx, fy, grid, models, train_errors, validation_errors, population_errors, validation_x, validation_y


@app.cell
def _(C, axes_pair, degree, fig_html, fx, fy, grid, mo, models, new_sample, noise, np, points, polynomial_training, polynomial_validation, show_truth, slide, train_errors, truth, validation_errors, validation_x, validation_y):
    _ff,_fa=axes_pair()
    if polynomial_validation.value:
        _fa[0].scatter(validation_x[:200],validation_y[:200],s=45,color=C["validation"],edgecolors=C["validation_edge"],alpha=1,marker="X",linewidths=.7,label="Validation observations")
    if polynomial_training.value:
        _fa[0].scatter(fx,fy,s=25,color=C["training"],alpha=.6,label="Training observations")
    _fa[0].plot(grid,models[degree.value-1](grid),color=C["fit"],lw=2.6,label=rf"Fitted curve $f_{{{degree.value}}}$")
    if show_truth.value:
        _fa[0].plot(grid,truth(grid),color=C["truth"],lw=2,ls="--",label="Population mean")
    _fa[0].set(xlabel="Input x",ylabel="Response y",title=f"Polynomial degree {degree.value}",ylim=(-2.5,3.5),xlim=(-1.04,1.04))
    _fa[0].legend(loc="lower right",fontsize=8)
    _degrees=np.arange(1,13)
    _fa[1].plot(_degrees,train_errors,"o-",color=C["training"],ms=4,label="Training loss")
    _fa[1].plot(_degrees,validation_errors,"X-",color=C["validation"],markeredgecolor=C["validation_edge"],markeredgewidth=.7,ms=6,lw=2,label="Validation loss")
    _fa[1].axhline(noise.value**2,color=C["truth"],ls=":",lw=1.5,label=r"Noise variance $\sigma^2$")
    _fa[1].axvline(degree.value,color=C["muted"],lw=1,alpha=.5)
    _fa[1].scatter([degree.value],[validation_errors[degree.value-1]],s=100,facecolors="none",edgecolors=C["validation_edge"],lw=1.5)
    _compressed=float(validation_errors.max())>2
    _fa[1].set(xlabel="Polynomial degree d",ylabel="Average squared error",title="Training and validation loss",xticks=[1,3,5,7,9,12],ylim=(0,max(.65,float(validation_errors.max())*1.2)))
    if _compressed:
        _fa[1].set_yscale("symlog",linthresh=.5)
    _fa[1].legend(fontsize=8,loc="upper left")
    _scale=" Loss axis: linear up to 0.5, logarithmic above." if _compressed else ""
    slide("6.3", "Polynomial regression", [
        mo.md(r"For each $d$, let $f_d$ be the least-squares polynomial of degree at most $d$."),
        mo.hstack([degree,points,noise],justify="start",gap=2),
        mo.hstack([new_sample,show_truth,polynomial_training,polynomial_validation],justify="start",gap=2),
        mo.Html('<div class="polynomial-figure">'+fig_html(_ff).text+'</div>'),
        mo.Html('<p class="small">Dotted line: noise variance, a lower bound for predictive risk only.</p>'),
        mo.md("**Validation loss** is the average squared error on 1,200 independent observations. These observations are used to compare degrees, so we call them validation data."),
        mo.Html('<p class="small">Changing degree keeps both samples fixed. At most 200 validation points shown; all 1,200 used.'+_scale+'</p>')
    ],"", "06")


@app.cell
def _(mo, slide):
    slide("6.3", "Increasing the polynomial degree", [mo.md(r"""
    Keep the training sample $D$ fixed. Write

    $$\mathcal P_d=\operatorname{span}\{1,x,\ldots,x^d\},$$

    and let $f_d$ minimise training loss over $\mathcal P_d$, as on the previous slide.
    Since $\mathcal P_d\subseteq\mathcal P_{d+1}$, the old fit $f_d$ is still available in the larger space.
    Hence

    $$\widehat R_D(f_{d+1})
    =\min_{f\in\mathcal P_{d+1}}\widehat R_D(f)
    \leq\widehat R_D(f_d).$$

    Training loss cannot increase. This gives no ordering of the predictive risks
    $R(f_{d+1})$ and $R(f_d)$, or of their validation losses.
    """),mo.accordion({"Underfitting and overfitting":mo.md(r"""
    **Underfitting:** the polynomial space is too restrictive to approximate the population mean well.

    **Overfitting:** extra flexibility reduces training loss but increases predictive risk by fitting variation specific to the training sample.

    Repeating the fit on fresh training samples reveals how sensitive the fitted curve is to that variation.
    """)})],"", "07")


@app.cell
def _(mo):
    bv_degree=mo.ui.slider(1,10,value=3,label="Polynomial degree",show_value=True,debounce=True)
    bv_n=mo.ui.slider(steps=[25,50,100,200],value=50,label="Training observations",show_value=True,debounce=True)
    bv_noise=mo.ui.slider(0,.8,step=.05,value=.35,label="Noise σ",show_value=True,debounce=True)
    bv_x=mo.ui.slider(-.85,.85,step=.05,value=.25,label="Inspect at x",show_value=True,debounce=True)
    bv_count=mo.ui.slider(steps=[1,5,20,80],value=20,label="Visible fits",show_value=True)
    return bv_degree, bv_n, bv_noise, bv_x, bv_count


@app.cell
def _(bv_degree, bv_n, bv_noise, fit_poly, np, sample_data):
    bv_grid=np.linspace(-1,1,300)
    bv_fits=[]
    for _b in range(240):
        _bx,_by=sample_data(bv_n.value,bv_noise.value,5000+_b)
        bv_fits.append(fit_poly(_bx,_by,bv_degree.value))
    bv_predictions=np.array([_m(bv_grid) for _m in bv_fits])
    return bv_fits, bv_grid, bv_predictions


@app.cell
def _(C, axes_pair, bv_count, bv_degree, bv_fits, bv_grid, bv_n, bv_noise, bv_predictions, bv_x, cards, fig_html, mo, np, slide, truth):
    _at=np.array([_m(bv_x.value) for _m in bv_fits])
    _target=float(truth(bv_x.value))
    _bvmean=float(_at.mean()); _bias2=(_bvmean-_target)**2; _variance=float(_at.var()); _noise2=bv_noise.value**2
    _bf,_ba=axes_pair()
    for _curve in bv_predictions[:bv_count.value]: _ba[0].plot(bv_grid,_curve,color=C["training"],lw=.8,alpha=.25 if bv_count.value>5 else .65)
    _ba[0].plot(bv_grid,bv_predictions.mean(axis=0),color=C["fit"],lw=2.6,label="Average of 240 fits")
    _ba[0].plot(bv_grid,truth(bv_grid),color=C["truth"],lw=2.2,ls="--",label="Population mean")
    _ba[0].axvline(bv_x.value,color=C["muted"],lw=1)
    _ba[0].set(ylim=(-2.5,3.5),xlabel="Input x",ylabel="Prediction",title="Fitted functions")
    _ba[0].legend(fontsize=8,loc="lower right")
    _ba[1].hist(_at,bins=25,color=C["training"],alpha=.65,density=True,label="Fitted predictions")
    _ba[1].axvline(_target,color=C["truth"],lw=2.4,ls="--",label="Population mean")
    _ba[1].axvline(_bvmean,color=C["fit"],lw=2.4,label="Average prediction")
    _ba[1].set(xlabel=f"Predicted response at x = {bv_x.value:.2f}",ylabel="Density",title="Predictions at a fixed x")
    _ba[1].legend(fontsize=8)
    _metrics=cards([
        ("",f"Squared bias: {_bias2:.3f}",r"$$(\bar z-\mu)^2$$"),
        ("",f"Variance: {_variance:.3f}",r"$$\frac1B\sum_{b=1}^B(z_b-\bar z)^2$$"),
        ("",f"Noise variance: {_noise2:.3f}",r"$$\sigma^2=\mathbb E[\varepsilon^2]$$"),
        ("",f"Prediction error at x: {_bias2+_variance+_noise2:.3f}",r"$$\frac1B\sum_{b=1}^B(z_b-\mu)^2+\sigma^2$$")
    ])
    slide("6.4", "Repeated training samples", [
        mo.hstack([bv_degree,bv_n,bv_noise,bv_x,bv_count],justify="start",gap=2),
        mo.Html('<p class="small">240 independent training samples; calculations use all fits. Move x to inspect predictions; Visible fits changes only the drawing.</p>'),
        mo.Html('<div class="bv-figure">'+fig_html(_bf).text+'</div>'),
        mo.md(r"""
        At the selected $x$, write $z_b=f_b(x)$ and $\bar z=B^{-1}\sum_{b=1}^B z_b$, with $B=240$.
        A fresh response is $Y=\mu+\varepsilon$, where $\mu$ is the population mean and $\mathbb E[\varepsilon]=0$.
        """),
        mo.Html('<div class="bv-summary">'+_metrics.text+'</div>'),
        mo.accordion({"What is being averaged?":mo.md(r"""
        **Squared bias** measures the squared distance between the average prediction $\bar z$ and the population mean $\mu$.
        **Variance** is the average squared distance of the predictions $z_b$ from their own mean $\bar z$.
        Both are estimates based on $B$ training samples.

        **Noise variance** describes variation of fresh responses about $\mu$.
        It is known in this simulation, rather than estimated from the fitted curves.

        For a fixed prediction $z_b$, averaging over the independent fresh noise gives

        $$\mathbb E_\varepsilon[(Y-z_b)^2]=(\mu-z_b)^2+\sigma^2.$$

        **Prediction error at x** averages this quantity over the $B$ fits.
        It estimates the expected squared error at this fixed $x$, averaging over both new responses and training samples.
        It does not average over input locations.
        """)})
    ],"", "08")


@app.cell
def _(mo, slide):
    slide("6.4", "Why the numbers on slide 8 add up", [mo.md(r"""
    Keep the same $B=240$ predictions $z_b$ at one fixed $x$.
    Their average is $\bar z$; the population mean response is $\mu$.

    Each prediction differs from $\mu$ in two parts:

    $$z_b-\mu=\underbrace{(z_b-\bar z)}_{\text{deviation from average}}
    +\underbrace{(\bar z-\mu)}_{\text{error of average}}.$$

    The deviations sum to zero: $\sum_b(z_b-\bar z)=0$.
    So when we square and average, the mixed term vanishes:

    $$\frac1B\sum_{b=1}^B(z_b-\mu)^2
    =\underbrace{\frac1B\sum_{b=1}^B(z_b-\bar z)^2}_{\text{variance}}
    +\underbrace{(\bar z-\mu)^2}_{\text{squared bias}}.$$

    A fresh response is $Y=\mu+\varepsilon$. Independent noise with mean zero adds its variance $\sigma^2$ to this squared error.
    Thus **prediction error = variance + squared bias + noise variance**.
    """),mo.accordion({
        "The mixed term, explicitly":mo.md(r"""
        Since $\bar z-\mu$ is the same for every prediction,

        $$\frac1B\sum_{b=1}^B2(z_b-\bar z)(\bar z-\mu)
        =2(\bar z-\mu)\frac1B\sum_{b=1}^B(z_b-\bar z)=0.$$

        In the inner product $\langle u,v\rangle=B^{-1}\sum_bu_bv_b$,
        deviations from the mean are orthogonal to constants. The identity is Pythagoras.
        """),
        "Why noise adds its variance":mo.md(r"""
        Keep one prediction $z_b$ fixed and average over a fresh response $Y=\mu+\varepsilon$:

        $$\mathbb E[(Y-z_b)^2]
        =(\mu-z_b)^2+2(\mu-z_b)\mathbb E[\varepsilon]+\mathbb E[\varepsilon^2]
        =(\mu-z_b)^2+\sigma^2.$$

        Now average over the $B$ predictions.
        """),
        "Population version":mo.md(r"""
        Replace the average over $B$ fits by an expectation over all training samples $D$.
        Write $m=\mathbb E_D[f_D(x)]$. The same calculation gives

        $$\mathbb E[(Y-f_D(x))^2]
        =(m-\mu)^2+\mathbb E_D[(f_D(x)-m)^2]+\sigma^2.$$

        Here $Y$ is a fresh response at the fixed $x$, independent of $D$.
        Assume finite second moments. Slide 8 estimates the averages over $D$ using 240 fits.
        """)
    })],"", "09")


@app.cell
def _(mo, slide):
    slide("6.5", "Choosing and assessing a degree", [mo.md(r"""
    Suppose we have 100 observations for choosing a polynomial degree, plus a separate test sample.

    **Fit on 80 observations.** For each $d=1,\ldots,8$, fit a degree-$d$ polynomial $f_d$ to these training observations.

    **Compare on the remaining 20.** Compute the validation loss

    $$V(d)=\frac1{20}\sum_{j=1}^{20}(y_j-f_d(x_j))^2,$$

    where $(x_j,y_j)$ are the 20 observations left out of fitting. Choose the degree with the smallest $V(d)$.

    **Assess the choice on fresh data.** Fit the chosen degree again using all 100 observations.
    Its test loss is the average squared error on the separate test sample.
    """),mo.accordion({"Why a separate test sample?":mo.md(r"""
    The 20 validation observations helped choose the degree, so the final polynomial depends on them.
    Choosing the smallest validation loss also favours degrees whose loss happened to be low on this particular sample.

    The test observations influence neither the coefficients nor the choice of degree.
    They assess the resulting polynomial. If we use them to revise the choice, they become validation data too.
    """)})],"", "10")


@app.cell
def _(mo):
    cv_degree=mo.ui.slider(1,8,value=3,label="Inspect degree",show_value=True,debounce=True)
    cv_fold=mo.ui.slider(1,5,value=1,label="Inspect round",show_value=True)
    cv_reveal=mo.ui.switch(value=False,label="Final test loss")
    cv_training=mo.ui.switch(value=True,label="Training points")
    cv_validation=mo.ui.switch(value=True,label="Validation points")
    cv_resplit=mo.ui.button(value=0,on_click=lambda v:v+1,label="New groups")
    cv_new_sample=mo.ui.button(value=0,on_click=lambda v:v+1,label="New training sample")
    return cv_degree, cv_fold, cv_reveal, cv_training, cv_validation, cv_resplit, cv_new_sample


@app.cell
def _(cv_new_sample, cv_resplit, fit_poly, np, sample_data, truth):
    cv_x,cv_y=sample_data(100,.4,37+int(cv_new_sample.value))
    cv_indices=np.random.default_rng(25+int(cv_resplit.value)).permutation(100)
    cv_folds=np.array_split(cv_indices,5)
    cv_losses=np.zeros((8,5))
    for _d in range(1,9):
        for _j,_held in enumerate(cv_folds):
            _keep=np.setdiff1d(np.arange(100),_held)
            _model=fit_poly(cv_x[_keep],cv_y[_keep],_d)
            cv_losses[_d-1,_j]=np.mean((cv_y[_held]-_model(cv_x[_held]))**2)
    cv_selected=int(np.argmin(cv_losses.mean(axis=1))+1)
    _cv_rng=np.random.default_rng(852)
    cv_test_x=_cv_rng.uniform(-1,1,2000)
    cv_test_y=truth(cv_test_x)+.4*_cv_rng.normal(size=2000)
    cv_final=fit_poly(cv_x,cv_y,cv_selected)
    cv_test_error=float(np.mean((cv_test_y-cv_final(cv_test_x))**2))
    return cv_x, cv_y, cv_folds, cv_losses, cv_selected, cv_test_error


@app.cell
def _(C, axes_pair, cv_degree, cv_fold, cv_folds, cv_losses, cv_new_sample, cv_resplit, cv_reveal, cv_selected, cv_test_error, cv_training, cv_validation, cv_x, cv_y, fig_html, fit_poly, mo, np, slide):
    _cf,_ca=axes_pair()
    _held=cv_folds[cv_fold.value-1]
    _keep=np.setdiff1d(np.arange(100),_held)
    _cm=fit_poly(cv_x[_keep],cv_y[_keep],cv_degree.value)
    _cg=np.linspace(-1,1,300)
    if cv_training.value:
        _ca[0].scatter(cv_x[_keep],cv_y[_keep],s=25,color=C["training"],alpha=.6,label="Training observations: 80")
    if cv_validation.value:
        _ca[0].scatter(cv_x[_held],cv_y[_held],s=45,color=C["validation"],edgecolors=C["validation_edge"],alpha=1,marker="X",linewidths=.7,label="Validation observations: 20")
    _ca[0].plot(_cg,_cm(_cg),color=C["fit"],lw=2,label=f"Degree {cv_degree.value} fit")
    _ca[0].set(xlabel="Input x",ylabel="Response y",title=f"Round {cv_fold.value}: fit 80, predict 20",ylim=(-2.5,3.5),xlim=(-1.04,1.04))
    _ca[0].legend(fontsize=8,loc="lower right")
    for _j in range(5):
        _ca[1].plot(np.arange(1,9),cv_losses[:,_j],color=C["muted"],alpha=.25,lw=1)
    _means=cv_losses.mean(axis=1)
    _ca[1].plot(np.arange(1,9),_means,"o-",color=C["fit"],lw=2.5,ms=4,label="Mean over five rounds")
    _ca[1].plot(np.arange(1,9),cv_losses[:,cv_fold.value-1],"X--",color=C["validation"],markeredgecolor=C["validation_edge"],markeredgewidth=.7,ms=6,lw=1.5,label=f"Round {cv_fold.value}")
    _ca[1].axvline(cv_degree.value,color=C["muted"],lw=1)
    _ca[1].scatter([cv_selected],[_means[cv_selected-1]],s=110,facecolors="none",edgecolors=C["validation_edge"],lw=1.5,label=f"Smallest mean: degree {cv_selected}")
    _ca[1].set(xlabel="Polynomial degree d",ylabel="Average squared error",title="Validation loss",xticks=np.arange(1,9),ylim=(0,max(.8,cv_losses.max()*1.1)))
    _ca[1].legend(fontsize=8)
    _round_loss=float(cv_losses[cv_degree.value-1,cv_fold.value-1])
    _mean_loss=float(_means[cv_degree.value-1])
    _assessment=(f"Its test loss on **2,000 fresh observations** is **{cv_test_error:.3f}**."
                 if cv_reveal.value else "The final test loss assesses this selected and refitted polynomial.")
    _roles=mo.Html('<div class="cv-groups">'+''.join(
        '<div class="'+('cv-group-validation' if r==cv_fold.value else 'cv-group-training')+'"><b>Group '+str(r)+'</b><span>'+('predict 20' if r==cv_fold.value else 'fit 20')+'</span></div>'
        for r in range(1,6))+'</div>')
    slide("6.5", "Use each group for validation once", [
        mo.md("Split 100 observations into five groups of 20. Each round fits four groups from scratch and predicts the fifth. **Two rounds share 60 training observations, so their errors are not independent.**"),
        mo.hstack([cv_degree,cv_fold,cv_training,cv_validation,cv_reveal],justify="start",gap=2),
        mo.hstack([cv_resplit,cv_new_sample,_roles],justify="start",gap=2),
        mo.Html('<p class="small">New groups keeps the observations; New training sample replaces them. The sliders only inspect existing fits.</p>'),
        mo.Html('<div class="cv-figure">'+fig_html(_cf).text+'</div>'),
        mo.md(f"For degree **{cv_degree.value}**: round {cv_fold.value} loss **{_round_loss:.3f}**; mean over five rounds **{_mean_loss:.3f}**."),
        mo.md(f"For these observations and groups, the smallest mean selects degree **{cv_selected}**. Refit on all **100** observations. "+_assessment)
    ],"", "11")


@app.cell
def _(mo, slide):
    slide("6.5", "What cross-validation averages", [mo.md(r"""
    For each observation $i$, let $\widehat y_i^{(d)}$ be the prediction from the degree-$d$ polynomial fitted **without its group**.
    Its squared error contributes once:

    $$\mathrm{CV}(d)=\frac1{100}\sum_{i=1}^{100}(y_i-\widehat y_i^{(d)})^2.$$

    Each group contains 20 observations, so this is also the mean of the five round losses:

    $$\mathrm{CV}(d)=\frac15\bigl(V_1(d)+\cdots+V_5(d)\bigr).$$

    Choose the degree with the smallest $\mathrm{CV}(d)$.
    Each error above comes from a fit on 80 observations; the final refit uses all 100.
    Its predictive risk is assessed by the separate test sample.
    """),mo.accordion({"If the groups have different sizes":mo.md(r"""
    Let group $r$ contain $n_r$ observations, with $n=\sum_rn_r$.
    If $V_r(d)$ is its average squared error, then

    $$\mathrm{CV}(d)=\sum_r\frac{n_r}{n}V_r(d).$$

    Weighting by group size gives each observation the same contribution.
    """)})],"", "12")


@app.cell
def _(mo):
    answers=mo.ui.switch(value=False,label="Answers")
    return answers,


@app.cell
def _(answers, mo, slide):
    _items=[("1","Increasing degree lowers training loss. Must predictive risk fall?","No. The larger space minimises loss on the training sample, not on the population."),("2","The histogram is wide, but its mean is close to the population mean. Which term is large?","Variance. Squared bias is small because the two means are close."),("3","Why does the smallest CV loss not replace the final test loss?","CV selected the degree and assessed fits on 80 observations. The independent test sample assesses the selected degree refitted on all 100.")]
    slide("6.2-6.5", "Questions", [answers,*[mo.Html('<div class="question"><span>'+a+'</span><div><b>'+b+'</b>'+('<p>'+c+'</p>' if answers.value else '')+'</div></div>') for a,b,c in _items]],"", "13")


@app.cell
def _(mo, slide):
    slide("6.2-6.5", "Summary", [mo.md(r"""
    **Predictive risk** is a population average. **Test loss** estimates it from fresh observations.

    Increasing polynomial degree cannot increase **training loss**, but may increase **predictive risk**.

    At a fixed input $x$, averaging over training samples and fresh responses gives

    $$\text{prediction error}=\text{squared bias}+\text{variance}+\text{noise variance}.$$

    Use **validation or cross-validation** to choose the degree.
    Refit the chosen degree, then assess it on an **independent test sample**.
    """)],"", "14")


if __name__ == "__main__":
    app.run()
