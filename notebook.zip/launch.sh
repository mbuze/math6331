#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
export MPLCONFIGDIR="${TMPDIR:-/tmp}/mher-matplotlib"
# Start with the existing teaching environment; no environment changes required.
exec /home/buze/miniforge3/envs/math4120/bin/marimo run lecture.py --no-sandbox --no-check --watch --port 2718 "$@"
