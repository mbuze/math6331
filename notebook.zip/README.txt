MATH6331: Statistical learning
Interactive lecture, 4 November 2026

START THE LIVE SLIDES

  ./launch.sh

This uses the existing math4120 conda environment and opens Marimo on
http://localhost:2718. If that port is occupied, use ./launch.sh --port 2719.
Use the on-screen next arrow / right arrow to advance. After using a slider,
click an empty part of the slide before using keyboard navigation.

Edit the notebook:

  conda run --no-capture-output -n math4120 marimo edit lecture.py

The notebook needs lecture.py, theme.css and layouts/lecture.slides.json.
The theme embeds the MARS and Lancaster logos and Inter fonts from the
MATH4120 course materials and local font installation. public/ contains the
original logos for the PDF build. The launcher watches notebook changes.
No files from the other teaching course are changed.

WHAT TO TRY FIRST

Slides 2-4: toggle training and test points without changing fits or losses.
Slide 4: assess three fits on 100 to 50,000 independent test observations;
resample the test set. At most 200 test points are plotted, all are scored.
Slide 6: change degree 1 -> 3 -> 10, add noise, then add observations.
Toggle training and validation points separately. Green validation loss uses
all 1,200 independent observations; at most 200 are plotted.
Slide 8: show more fitted curves; move x towards the boundary.
Slide 10: choose a degree using 80 training and 20 validation observations.
Slide 11: rotate the group of 20 left out. Inspect degree and round, toggle
points, then reveal test loss for the selected degree refitted on all 100.
New groups reshuffles the same observations; New training sample draws new
observations. Both recompute selection; inspection sliders do not.
Slide 12: express the same CV calculation as an average over observations.
Slide 14: concise summary of the lecture.

Notation: f_D denotes the fitted function (written with a hat in the notes).
The main lecture uses squared error. Slide 9 derives the bias-variance split
using the 240 predictions from slide 8, with x fixed throughout. The optional
population version averages f_D(x) over all training samples.

All examples use synthetic, reproducible data. The Figure 6.1 experiment is
inspired by the lecture notes; it does not reproduce the Wage dataset.
The training sample is preserved when n grows. Degree changes do not resample.
High-degree curves may leave the fixed plotting window. Large MSE values use
a compressed axis when necessary; its labels always show actual MSE values.

FILES FOR REVIEW / DISTRIBUTION

exports/handout.pdf      Static PDF companion (14 pages).
exports/lecture.html     Marimo HTML snapshot; answers revealed.
exports/browser/        Interactive WebAssembly export; requires HTTP hosting.
exports/notebook.zip    Notebook, theme and slide layout for sharing.

The PDF is a separately typeset static companion, not a screenshot of the
browser layout. Controls are omitted; the plots use the default settings.
The static HTML is not interactive and may need internet for Marimo assets.

To try the browser-only version locally:

  python -m http.server 8000 --directory exports/browser

Then visit http://localhost:8000. This export loads Python and packages in the
browser and requires an internet connection on first use. It is ready for
static hosting, but has not been published or browser-tested in this session.

REBUILD AND CHECK

  conda run --no-capture-output -n math4120 python scripts/validate.py
  conda run --no-capture-output -n math4120 python scripts/export_draft.py
  conda run --no-capture-output -n math4120 marimo export html-wasm lecture.py -o exports/browser --mode run -f

The socket-free static exporter uses Marimo 0.23.9 internals. For other versions,
prefer the standard 'marimo export html' command. In normal environments the
native slide PDF exporter is also available; this draft's companion is built
with scripts/build_handout.py (BeautifulSoup) and XeLaTeX.

VALIDATION / REMAINING REVIEW

All notebook cells execute. Numerical checks cover sample nesting, the nested
least-squares loss inequality, CV partitioning, the bias-variance identity,
and representative extreme control settings. Exported figures and the PDF
were visually inspected. Live slider and projector layout review is still
needed: this agent session could not bind local server sockets and had no
connected browser. No conda environment was modified.

PUBLISHING

Run ./publish.sh --publish to publish on GitHub Pages at
https://mbuze.github.io/math6331/. See PUBLISHING.txt for details.
